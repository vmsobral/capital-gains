# Code Challenge: Ganho de Capital

Programa de linha de comando que visa calcular o imposto a ser pago sobre lucros ou prejuízos de operações no mercado financeiro de ações a partir de uma entrada em formato JSON.

## Requisitos
- node v21.7.3
- npm 10.5.0
- docker 24.0.5

## Como rodar

1. Habilite o script `start.sh` para execução

```
sudo chmod u+x start.sh
```

2. Execute o script para buildar a imagem Docker e rodar o container com linha de comando habilitada. Caso a entrada seja através de um arquivo, passe o mesmo como argumento para o script

```
./start.sh
```

OU

```
./start.sh example.json
```

3. Após execução do container, rode o programa pela linha de comando (não altere o nome do arquivo aqui), ou simplesmente rode o programa sem qualquer argumento. Nesse caso ele esperará as entradas via linha de comando.

```
node src/index.js < file.txt
```

OU

```
node src/index.js
```


## Sobre a escolha da linguagem

- A escolha pela linguagem de programação Javascript com Node.js se deu por se tratar da linguagem que possuo maior prática recente e, portanto, maior conforto em desenvolver no momento. Além disso, se trata de uma linguagem simples, imperativa, de tipagem dinâmica, facilmente testável pelo interpretador do node.js  e, por ser um exercício simples e com poucas dependências externas, considerei que não haveriam maiores problemas em desenvolver nessa linguagem.

- Considero que, em se tratando de um exercício mais complexo, com necessidade de várias estruturas de dados, interfaces, tipagem forte, conexões em banco de dados e outras ferramentas externas como Filas, APIs e Serviços de Cloud, eu poderia optar por outra linguagem, ainda que eu saiba que o Javascript possui suporte à múltiplos paradigmas, como Orientação à Objetos e Funcional e tendo eu mesmo já desenvolvido aplicações robustas, com todas essas necessidades, nessa linguagem. Acredito que cada caso de uso possa ser avaliado para se escolher a linguagem mais apropriada.

## Sobre algumas escolhas de desenvolvimento e limitações conhecidas

- Apenas um arquivo com os métodos principais de cálculo foi criado (`taxesCalculator.js`), pois considerei o problema ser simples o suficiente para lidar assim, mantendo a legibilidade do código.

- O arquivo `index.js` é o arquivo principal à ser chamado por linha de comando e possui apenas a função de ler as entradas e separar as listas com as operações para enviar ao método de cálculo.

- Optei por utilizar a sintaxe CommonJS para importar os módulos (`const util = require('util")`), pela praticidade e por ter menos experiência com módulos ES (`import { method } from 'module'`), mas sei ser possível e mais moderno e, tendo um tempo maior, poderia fazê-lo.

- No método `calculateTaxAndAccumulatedLoss`, optei por uma abordagem "Fail Fast", retornando imediatamente o resultado após uma condição final ser atendida. Ainda que seja um método simples, a escolha desse design pattern e de vários "ifs" (poderia ter juntado todas as condições em apenas um) foi para priorizar a organização e legibilidade do código.

- Nos testes unitários optei por testar o fluxo principal completo, ao invés dos métodos separadamente, por considerar os mesmos simples o suficiente e ter como base as entradas fornecidas pela descrição do exercício já prontas. Fosse o contrário, seria preciso criar casos de uso intermediários para os testes.