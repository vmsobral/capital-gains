/**
 * Receives a JSON containing a single list of operations and iterates over it, calculating and printing taxes paid for each operation.
 * 
 * @param {*} allOpsJson
 * @returns a list containing the taxes paid for each operation
 */
function calculateTaxes (allOpsJson) {

    // Initialize variables for calc. Since there must be no state, those are initialized and maintained at runtime
    let averagePrice = 0, totalQuantity = 0, accumulatedLoss = 0
    const taxesResult = []

    // Iterate through a single list of operations
    for (let op of allOpsJson) {

        // Taxes are calculated for each operation separately, so it must be initialized on every iteration
        let taxes = 0

        // Process buy
        if (op.operation === "buy") {
            averagePrice = ((totalQuantity * averagePrice) + (op.quantity * op["unit-cost"])) / (totalQuantity + op.quantity)
            totalQuantity += op.quantity
        }

        // Process sell
        if (op.operation === "sell") {
            [ taxes, accumulatedLoss ] = calculateTaxAndAccumulatedLoss(averagePrice, op.quantity, op["unit-cost"], accumulatedLoss)

            // Reset averagePrice if totalQuantity held reaches 0, so it can be recalculated when there is a new buy
            totalQuantity -= op.quantity
            if (totalQuantity === 0) {
                averagePrice = 0
            }
        }

        taxesResult.push({"tax": taxes})
    }
    return taxesResult
}

/**
 * Calculates taxes and accumulated losses for a single sell operation
 * 
 * @param {*} averagePrice 
 * @param {*} opQuantity 
 * @param {*} opUnitCost 
 * @param {*} previousLoss 
 * @returns a list of 2 containing the tax paid on the first position and the accumulated loss on the second position
 */
function calculateTaxAndAccumulatedLoss (averagePrice, opQuantity, opUnitCost, previousLoss) {

    const opTotalValue = opUnitCost * opQuantity
    const opPnL = opTotalValue - averagePrice * opQuantity
    const pnLAfterDeductingLosses = previousLoss + opPnL
    const accumulatedLoss = pnLAfterDeductingLosses >= 0 ? 0 : pnLAfterDeductingLosses

    // Do not pay taxes if total operation value is less or equal 20k
    if (opTotalValue <= 20000) {
        return [0, accumulatedLoss]
    }

    // Do not pay taxes if op is deficitary
    if (opPnL < 0) {
        return [0, accumulatedLoss]
    }

    // Do not pay taxes if there are accumulated losses to deduct
    if (accumulatedLoss < 0) {
        return [0, accumulatedLoss]
    }

    // Else, calculate taxes
    const totalTaxes = 0.2 * pnLAfterDeductingLosses
    return [totalTaxes, 0]
}

module.exports = {
    calculateTaxes
}