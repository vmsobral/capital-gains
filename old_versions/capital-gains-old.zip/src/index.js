const readline = require('readline')
const taxesCalculator = require('./taxesCalculator')

async function run () {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout,
        terminal: false
    })

    let jsonInputString = ""

    rl.on('line', (line) => {
        // Reads lines until a well-formed complete JSON is provided
        jsonInputString = jsonInputString.concat(" ", line)
        let jsonInput
        try {
            jsonInput = JSON.parse(jsonInputString)
        } catch (e) {
            // If parsing the JSON throws an error, ignore and wait for another line
            return
        }
        // Calculates taxes and prints result on stdout
        const taxesResult = taxesCalculator.calculateTaxes(jsonInput)
        console.log(JSON.stringify(taxesResult))
        
        // Reset JSON Input if there is another batch of operations to calculate
        jsonInputString = ""
    })

    rl.once ('close', () => {
        return 0
    })
}
  
run().then(
    () => { return 0 },
    err => {
        if (err.response) {
            console.log(err.response.status, err.response.headers, err.response.data)
        } else {
            console.log(err)
        }
    }
)
